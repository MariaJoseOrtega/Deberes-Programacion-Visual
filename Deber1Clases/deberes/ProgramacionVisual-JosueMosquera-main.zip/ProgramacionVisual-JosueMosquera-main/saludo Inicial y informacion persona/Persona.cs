using System;

namespace myapp
{
    class Persona
    {
        public string nombre;
        public int edad;
        public float peso;
        public bool esAficionadoAlFutbol;
        public DateTime fechaDeCreacionRegistro;
        public float estatura;
        public string deporteFavorito;
        public string pasatiempoFavorito;
        public double sueldoMensual;
        public string semestre;

    }






}